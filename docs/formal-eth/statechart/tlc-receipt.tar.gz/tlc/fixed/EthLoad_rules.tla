---- MODULE EthLoad_rules ----
EXTENDS EthLoad
StatechartTLC == INSTANCE TLC
StatechartBroken == (IF TypeOK THEN {} ELSE {"TypeOK"}) \cup (IF ReadyHasUsableView THEN {} ELSE {"ReadyHasUsableView"}) \cup (IF NoHiddenPublication THEN {} ELSE {"NoHiddenPublication"}) \cup (IF NoStalePublication THEN {} ELSE {"NoStalePublication"}) \cup (IF NavigationSurvivesRefresh THEN {} ELSE {"NavigationSurvivesRefresh"}) \cup (IF ReadinessOnce THEN {} ELSE {"ReadinessOnce"})
StatechartRules == StatechartBroken = {} \/ StatechartTLC!PrintT(<<"statechart broken", [s |-> s], StatechartBroken>>)
====
